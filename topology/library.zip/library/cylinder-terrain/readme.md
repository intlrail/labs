# our new land [SVG]

[source](https://codepen.io/ge1doot/pen/jdgGbB).

plotter SVG
