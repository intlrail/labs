# Messing with simple terrain generation

A Pen created on CodePen.io. Original URL: [https://codepen.io/loktar00/pen/BCEvp](https://codepen.io/loktar00/pen/BCEvp).

The doom melt effect got me thinking about simple terrain, trying to avg the neighbors both in front and behind to make a cool effect. Thanks also to @jackrugile for helping me out on my twitch stream :) Heres Jacks Pen that he worked on as well. Ours are pretty close http://codepen.io/jackrugile/pen/9c8c8606958690378a6044dddc64faaf 
