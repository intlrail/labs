module.exports = require('./lib/terrain.js');
