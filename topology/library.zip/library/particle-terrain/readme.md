# Elevation map

A Pen created on CodePen.io. Original URL: [https://codepen.io/kevinnewcombe/pen/XMVoKv](https://codepen.io/kevinnewcombe/pen/XMVoKv).

Data from the Google Maps Elevation API mapped onto a three.js particle system
