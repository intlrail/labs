# Diamond-Square Terrain II

Based on [Diamond-Square Terrain](https://codepen.io/ashmind/pen/qALth) by AshMind.
