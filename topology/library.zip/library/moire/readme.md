# Oriented

A Pen created on CodePen.io. Original URL: [https://codepen.io/ge1doot/pen/wPymJv](https://codepen.io/ge1doot/pen/wPymJv).

Dizzy after the seemingly never-ending journey, only the waterfall kept me oriented. Or so I thought.
