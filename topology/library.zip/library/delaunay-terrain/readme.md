# Delaunay Stripes

Based on [Delaunay Stripes](https://codepen.io/DonKarlssonSan/pen/NWGwyYJ) by Johan Karlsson.